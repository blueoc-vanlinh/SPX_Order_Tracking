# Bộ khung cào onsite SPX

Đã bổ sung chế độ **Order Tracking chỉ lấy total** trong mã nguồn (nút **Σ**),
cấu hình Google Sheet riêng và danh sách 40 Next Station. Đã nối endpoint và
giá trị lọc từ bot SOC; chưa kiểm tra mạng thực tế, chưa cập nhật EXE.
Mở `crawl_tracking_totals.bat` hoặc xem [ORDER_TRACKING.md](ORDER_TRACKING.md).

## App Windows

Chạy `setup.bat` rồi mở `open_app.bat` để dùng giao diện. Chạy `build_app.bat` để tạo EXE và ZIP chia sẻ trên Windows có Internet. Xem [hướng dẫn app](APP_GUIDE.md). Bản đóng gói không kèm phiên đăng nhập hay dữ liệu đã tải.

Python 3.10+ trên Windows, Google Chrome đã cài. Đây là bộ độc lập, chưa sửa dự án SOC cũ. Chưa cấu hình API thực tế.

## Chạy nhanh

1. Giải nén vào thư mục riêng, ví dụ `C:\SPX_Crawler`.
2. Chạy `setup.bat` một lần.
3. Chạy `login.bat`: Chrome dùng profile riêng mở SPX. Tự đăng nhập/OTP, chọn Hung Yen SOC, quay lại cửa sổ lệnh và nhấn Enter.
4. Phiên lưu ở `.auth/storage_state.json`; cookies và CSRF xuất riêng ở `.auth/spx_auth_cache.json`. Chỉ kiểm tra sự hiện diện cookie; chưa kết luận đăng nhập hợp lệ khi chưa có API kiểm tra.
5. Sau khi điền API thật vào `config/api.json`, chạy `crawl.bat`.
6. Kết quả nằm trong `outputs/<thời gian>/`: từng response trang, `data.json`, `data.csv`, `summary.json`. CSV mở bằng Excel được, hỗ trợ tiếng Việt.

Không gửi thư mục `.auth` cho người khác. Không cần cung cấp mật khẩu cho chương trình. File cache chỉ là bản chụp khi đăng nhập; bộ cào sử dụng storage_state đã cập nhật sau mỗi lần chạy. LocalStorage được giữ trong storage state nhưng nếu API cần Authorization hoặc token riêng thì phải bổ sung sau khi có thông tin API.

## Lệnh PowerShell

```powershell
.\.venv\Scripts\python.exe app.py login
.\.venv\Scripts\python.exe app.py status
.\.venv\Scripts\python.exe app.py crawl --config config/api.json
```

Nếu không dùng Chrome: `.\.venv\Scripts\python.exe -m playwright install chromium`, sau đó `app.py login --browser chromium`. Nếu Google SSO từ chối trình duyệt tự động, dừng và báo lỗi để nối phương án Chrome debug như SOC cũ; không bỏ qua kiểm soát đăng nhập.

## Cấu hình API

`api.json` cố ý có path rỗng để tránh gọi nhầm endpoint. Chỉ hỗ trợ API tra cứu GET/POST cùng origin SPX. Chưa có endpoint nghiệp vụ nào được giả định.

- `path`: `/api/...`, không chứa query string.
- `method`: `GET` hoặc `POST` (chỉ API đọc/tìm kiếm).
- `params`: tham số trên URL; `body`: JSON của POST.
- `rows_path`: đường dẫn đến danh sách, ví dụ `data.list` (chỉ minh họa cấu trúc).
- `success`: ví dụ `{"path":"retcode","equals":0}` nếu API có mã nghiệp vụ. Bỏ/null khi không áp dụng.
- `dedupe_key`: tên trường ID duy nhất, hoặc null để giữ nguyên dòng.
- `pagination.mode`: `none` khi chưa biết phân trang; `page` khi phân trang theo số.
- `pagination.location`: `params` hoặc `body`; các tên `page_param`, `size_param` phải khớp API.
- `stop_on_short_page`: chỉ bật nếu API kết thúc bằng trang ít hơn size; nếu false sẽ chạy đến trang rỗng hoặc giới hạn.
- `max_pages`: giới hạn bảo vệ; chạm giới hạn thì đánh dấu kết quả chưa hoàn tất.

GET retry tối đa 3 lần khi HTTP 429/5xx. POST không tự retry. Timeout 30 giây, dừng khi 401/403/redirect/không phải JSON, kiểm tra success nếu cấu hình. Cookie CSRF cập nhật mỗi trang. Nếu lỗi giữa chừng, dữ liệu trang đã tải và summary được giữ lại; chưa hỗ trợ resume tự động, phân trang cursor/offset, lịch chạy, workers hoặc giao diện web.

## Khi cấp API

Gửi URL, method, query/body, mẫu JSON response đã xóa dữ liệu nhạy cảm, quy tắc phân trang và trường ID. Không cần gửi cookies/token thật. Khi đó sẽ nối adapter nghiệp vụ, kiểm tra quyền đăng nhập thật và bổ sung giao diện/lịch chạy nếu cần.

## Kiểm tra

`python -m unittest discover -s tests -v`

Kiểm tra offline cho phân trang, chống lặp, lỗi phiên, xuất dữ liệu và chống công thức CSV. Đăng nhập Chrome và API SPX phải kiểm tra trên máy có tài khoản/quyền truy cập.

Tham khảo kỹ thuật: https://playwright.dev/python/docs/auth và https://playwright.dev/python/docs/api/class-apirequestcontext


## Bản Onsite: hai endpoint đã cấp

Đã thêm config cho `onsite_registration/group/list_v2` và `onsite_registration/list_v2`.
Mẫu response có `retcode=0`, `data.list`, `data.total`, `data.pageno`, `data.count`. Detail dedupe bằng `id`, group bằng `standby_hour_start`. Giữ mã arrival_status nguyên bản vì chưa có bảng mapping trạng thái chính thức.

1. Chạy `capture_onsite.bat` thay cho login nếu muốn lấy cả request và phiên.
2. Tool mở thẳng trang Onsite và tự mở rộng các khung giờ. Đăng nhập/chọn Hung Yen SOC nếu SPX yêu cầu; không cần bấm mở từng giờ.
3. Quay lại terminal, Ctrl+C để lưu phiên. Hai cấu hình sẽ nhận method/query/JSON body vừa quan sát. Mỗi request mới ghi đè cấu hình cùng loại, do đó bộ lọc giữ theo thao tác cuối.
4. Chạy `crawl_onsite_group.bat` hoặc `crawl_onsite_detail.bat`.

Chế độ bắt request không lưu headers/cookies vào config. Chỉ bắt hai endpoint đúng origin SPX. Xem lại config nếu query/body có token đặc thù. Chưa xác nhận request bằng response lúc capture; lần crawl đầu kiểm tra retcode và JSON. Nếu không bắt được request, gửi Request Method, Query String Parameters và Request Payload từ DevTools, xóa token/cookies.

Phân trang chỉ tự bật khi request thực có pageno/count; bộ cào bắt đầu trang 1, dừng khi số bản ghi nhận đủ data.total. Nếu thiếu khóa phân trang và response chưa đủ total thì báo chưa hoàn tất. Nút ▶ trong app, hoặc `python app.py crawl-all-onsite`, lấy toàn bộ group rồi tải chi tiết từng khung giờ. Tham số giờ được xác định bằng cách đối chiếu request chi tiết đã bắt với thời gian trong group; nếu không xác định được, app yêu cầu bắt lại cùng ngày/bộ lọc.

Mở `data.xlsx` để xem dữ liệu Excel. Mỗi trường lồng nhau được tách thành cột riêng; tuyến đường có thêm tên trạm dạng chữ thay vì chuỗi JSON. CSV cũng dùng các cột này. Cột Time có dạng `2026-11-14 06:00AM - 2026-11-14 06:59AM`, theo giờ Việt Nam. `data.json` giữ dữ liệu gốc. Lần tải toàn bộ gộp chi tiết các giờ vào một file; các response gốc nằm trong `groups` và `slots`. `summary.json` ghi số khung giờ hoàn tất và đánh dấu chưa đủ khi lỗi giữa chừng. Không suy diễn trạng thái hay tự truy vấn trường số điện thoại đang bị SPX chặn.

Chọn ngày ở ⋯ rồi bấm ▶: tool tự mở trang Onsite, mở rộng các khung giờ và dùng API để tải hết chi tiết. Các cột giờ gốc trong Excel/CSV, gồm `standby_hour_start`, được thay trực tiếp bằng ngày/giờ đọc được. Google Sheets tùy chọn trong ⋯ → Google Sheets…; xem [hướng dẫn](GOOGLE_SHEETS.md).

Response bạn cung cấp xác định Hung Yen SOC là 3909; chưa tự chèn tham số station_id hoặc ngày khi chưa thấy request thật. Không đóng gói dữ liệu tài xế mẫu trong bản phát hành.
