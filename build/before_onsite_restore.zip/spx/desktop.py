"""Small desktop interface; all Playwright operations stay on one worker thread."""
import contextlib
import importlib.util
import json
import os
import queue
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext, filedialog
from datetime import datetime, date
from pathlib import Path

from .core import ROOT, STATE, CrawlError, crawl, login


class LogStream:
    def __init__(self, events):
        self.events = events

    def write(self, value):
        if value:
            self.events.put(("log", value))
        return len(value)

    def flush(self):
        pass


class Desktop:
    def __init__(self, window, exit_app=None):
        self.window = window
        self.exit_app = exit_app or window.destroy
        self.events = queue.Queue()
        self.finished = threading.Event()
        self.busy = False
        self.mode = None
        from .onsite import VN
        self.day = tk.StringVar(value=datetime.now(VN).date().isoformat())
        self.tooltip = None
        self.drag_origin = None
        self.details = None
        self.log = None
        self.log_lines = []
        self.bg = "#17212e"
        window.title("SPX Onsite Crawler")
        window.overrideredirect(True)
        window.attributes("-topmost", True)
        window.attributes("-alpha", 0.62)
        window.configure(bg=self.bg)
        left, top, right, bottom = self.work_area()
        window.geometry(f"68x402+{right - 80}+{max(top, top + (bottom - top - 402) // 2)}")
        frame = tk.Frame(window, bg=self.bg, padx=8, pady=6,
                         highlightbackground="#394657", highlightthickness=1)
        frame.pack(fill="both", expand=True)
        titlebar = tk.Frame(frame, bg=self.bg)
        titlebar.pack(fill="x", pady=(2, 3))
        self.exit_button = tk.Button(titlebar, text="×", command=self.close,
                                     font=("Segoe UI", 13, "bold"), fg="#ff9595",
                                     bg=self.bg, activebackground="#713b45",
                                     activeforeground="white", relief="flat", bd=0,
                                     highlightthickness=0, padx=0, pady=0, cursor="hand2")
        self.exit_button.pack(side="right")
        self.bind_tip(self.exit_button, "Tắt công cụ")
        header = tk.Label(titlebar, text="SPX", font=("Segoe UI", 8, "bold"),
                          fg="#ffb078", bg=self.bg, cursor="fleur")
        header.pack(side="left", fill="x", expand=True)
        header.bind("<ButtonPress-1>", self.drag_start)
        header.bind("<B1-Motion>", self.drag_move)
        header.bind("<ButtonRelease-1>", self.drag_end)
        self.bind_tip(header, "Kéo để di chuyển thanh công cụ")
        self.status = tk.StringVar()
        self.hint = tk.StringVar(value="Đăng nhập hoặc bắt cấu hình Onsite để bắt đầu.")
        self.indicator = tk.Label(frame, text="●", fg="#95a1b2", bg=self.bg,
                                  font=("Segoe UI", 8))
        self.indicator.pack()
        self.bind_tip(self.indicator, lambda: self.hint.get() + "\n" + self.status.get())
        self.actions = []
        for icon, tip, mode in [("↪", "Đăng nhập SPX", "login"),
                                ("◎", "Bắt cấu hình Onsite", "capture"),
                                ("▷", "Chạy tải tổng hợp", "group"),
                                ("▶", "Tải chi tiết tất cả khung giờ", "detail"),
                                ("Σ", "Order Tracking: tổng đơn HY SOC / Next Station", "tracking")]:
            button = self.icon_button(frame, icon, tip, lambda m=mode: self.start(m))
            self.actions.append(button)
        self.save = self.icon_button(frame, "✓", "Lưu phiên / Kết thúc bắt cấu hình", self.finish)
        self.save.configure(state="disabled", fg="#72e0af")
        tk.Frame(frame, bg="#394657", height=1).pack(fill="x", pady=5)
        self.icon_button(frame, "▤", "Mở kết quả CSV / JSON", lambda: self.open_folder("outputs"))
        self.icon_button(frame, "⋯", "Nhật ký và cấu hình", self.show_details)
        window.update_idletasks()
        height = frame.winfo_reqheight()
        window.geometry(f"68x{height}+{right - 80}+{max(top, top + (bottom - top - height) // 2)}")
        window.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        window.after(100, self.poll)
        window.after(120, self.update_opacity)

    def work_area(self):
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            rect = wintypes.RECT()
            if ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0):
                return rect.left, rect.top, rect.right, rect.bottom
        return 0, 0, self.window.winfo_screenwidth(), self.window.winfo_screenheight()

    def icon_button(self, parent, icon, tip, command):
        button = tk.Button(parent, text=icon, command=command, font=("Segoe UI Symbol", 18),
                           bg=self.bg, fg="#edf3fa", activebackground="#35475d",
                           activeforeground="#ffb078", disabledforeground="#536173",
                           relief="flat", bd=0, highlightthickness=0, cursor="hand2",
                           takefocus=True, pady=0)
        button.pack(fill="x", pady=1)
        button.bind("<Enter>", lambda e: button.configure(bg="#29394c"))
        button.bind("<Leave>", lambda e: button.configure(bg=self.bg))
        self.bind_tip(button, tip)
        return button

    def bind_tip(self, widget, tip):
        widget.bind("<Enter>", lambda e: self.show_tip(widget, tip), add="+")
        widget.bind("<Leave>", lambda e: self.hide_tip(), add="+")
        widget.bind("<ButtonPress-1>", lambda e: self.hide_tip(), add="+")

    def show_tip(self, widget, tip):
        self.hide_tip()
        popup = self.tooltip = tk.Toplevel(self.window)
        popup.overrideredirect(True)
        popup.attributes("-topmost", True)
        tk.Label(popup, text=tip() if callable(tip) else tip, bg="#263548", fg="white",
                 font=("Segoe UI", 10), padx=12, pady=8, wraplength=310, justify="left").pack()
        popup.update_idletasks()
        left, top, right, bottom = self.work_area()
        x = max(left, min(right - popup.winfo_reqwidth(), self.window.winfo_x() - popup.winfo_reqwidth() - 8))
        y = max(top, min(bottom - popup.winfo_reqheight(), widget.winfo_rooty()))
        popup.geometry(f"+{x}+{y}")

    def hide_tip(self):
        if self.tooltip is not None:
            self.tooltip.destroy()
            self.tooltip = None

    def update_opacity(self):
        x, y = self.window.winfo_pointerxy()
        inside = (self.window.winfo_x() <= x < self.window.winfo_x() + self.window.winfo_width()
                  and self.window.winfo_y() <= y < self.window.winfo_y() + self.window.winfo_height())
        self.window.attributes("-alpha", 0.96 if inside else 0.62)
        self.window.after(120, self.update_opacity)

    def drag_start(self, event):
        self.drag_origin = (event.x_root - self.window.winfo_x(), event.y_root - self.window.winfo_y())

    def drag_move(self, event):
        if self.drag_origin:
            left, top, right, bottom = self.work_area()
            x = max(left, min(right - 68, event.x_root - self.drag_origin[0]))
            y = max(top, min(bottom - self.window.winfo_height(), event.y_root - self.drag_origin[1]))
            self.window.geometry(f"+{x}+{y}")

    def drag_end(self, event):
        self.drag_origin = None

    def show_details(self):
        if self.details is not None and self.details.winfo_exists():
            self.details.deiconify()
            self.details.lift()
            return
        panel = self.details = tk.Toplevel(self.window)
        panel.title("SPX · Nhật ký")
        panel.geometry("560x410")
        day_row = tk.Frame(panel)
        day_row.pack(fill="x", padx=12, pady=(10, 0))
        tk.Label(day_row, text="Ngày dữ liệu (YYYY-MM-DD):").pack(side="left")
        tk.Entry(day_row, textvariable=self.day, width=14).pack(side="left", padx=8)
        tk.Label(panel, text="Lưu cấu hình một lần. Chọn ngày rồi bấm ▶ để tự tải tất cả khung giờ.", wraplength=530).pack(pady=4)
        tk.Label(panel, textvariable=self.hint, wraplength=490, justify="left", padx=12, pady=10).pack(fill="x")
        self.log = scrolledtext.ScrolledText(panel, font=("Consolas", 10), wrap="word", height=9)
        self.log.pack(fill="both", expand=True, padx=12)
        self.log.insert("end", "".join(self.log_lines))
        self.log.configure(state="disabled")
        buttons = tk.Frame(panel)
        buttons.pack(fill="x", padx=12, pady=8)
        tk.Button(buttons, text="Mở cấu hình", command=lambda: self.open_folder("config")).pack(side="left")
        tk.Button(buttons, text="Google Sheets…", command=self.sheet_settings).pack(side="left", padx=8)
        tk.Button(buttons, text="Đẩy kết quả gần nhất", command=lambda: self.start("sheets")).pack(side="left")
        tracking_buttons = tk.Frame(panel)
        tracking_buttons.pack(fill="x", padx=12, pady=(0, 8))
        tk.Button(tracking_buttons, text="Sheet Order Tracking…", command=lambda: self.sheet_settings(tracking=True)).pack(side="left")
        tk.Button(tracking_buttons, text="Gửi tổng đơn gần nhất", command=lambda: self.start("tracking_sheets")).pack(side="left", padx=8)
        tk.Button(tracking_buttons, text="Đăng nhập Tracking", command=lambda: self.start("tracking_login")).pack(side="left")
        tk.Button(panel, text="Bộ lọc Order Tracking…", command=self.tracking_filters).pack(anchor="w", padx=12, pady=(0, 8))
        panel.protocol("WM_DELETE_WINDOW", panel.withdraw)

    def tracking_filters(self):
        from tkinter import ttk
        from .tracking import load_config, apply_profile, requests
        from .core import write_json
        cfg = load_config()
        profiles = cfg.get("profiles", {"all": {"label": "Tất cả đơn", "filters": {}}})
        dialog = tk.Toplevel(self.window)
        dialog.title("Bộ lọc Order Tracking")
        dialog.geometry("560x370")
        tk.Label(dialog, text="Chọn bộ lọc hoặc nhập tên mới. Bộ all luôn lấy tổng toàn bộ HY SOC.", wraplength=530).pack(padx=12, pady=8)
        selected = tk.StringVar(value=cfg.get("active_profile", "all"))
        combo = ttk.Combobox(dialog, textvariable=selected, values=list(profiles))
        combo.pack(fill="x", padx=12)
        tk.Label(dialog, text="Điều kiện bổ sung (JSON từ payload API; ví dụ Order Status dùng trường order_status):", wraplength=530).pack(padx=12, pady=8)
        editor = scrolledtext.ScrolledText(dialog, height=8, font=("Consolas", 10))
        editor.pack(fill="both", expand=True, padx=12)
        def show(event=None):
            editor.delete("1.0", "end")
            editor.insert("1.0", json.dumps(profiles.get(selected.get(), {}).get("filters", {}), ensure_ascii=False, indent=2))
        combo.bind("<<ComboboxSelected>>", show)
        show()
        tk.Label(dialog, text="Current Station giữ HY SOC; vẫn lấy riêng 40 Next Station.\nBộ lọc khác all có dòng Sheet riêng dạng tên trạm | tên bộ lọc.", justify="left").pack(padx=12, pady=8)
        def save():
            try:
                name = selected.get().strip()
                filters = json.loads(editor.get("1.0", "end"))
                if not name or not isinstance(filters, dict) or (name == "all" and filters):
                    raise CrawlError("Nhập tên bộ lọc và JSON object. Bộ all phải để {} để lấy tổng toàn bộ.")
                profiles[name] = {"label": name, "filters": filters}
                value = {**cfg, "profiles": profiles, "active_profile": name}
                requests(apply_profile(value))
                write_json(ROOT / "config" / "order_tracking.json", value)
                dialog.destroy()
            except (ValueError, CrawlError) as exc:
                messagebox.showerror("Chưa lưu được", str(exc), parent=dialog)
        tk.Button(dialog, text="Lưu và dùng bộ lọc này", command=save).pack(pady=8)

    def sheet_settings(self, tracking=False):
        from .sheets import load_config, spreadsheet_id
        from .core import write_json
        if tracking:
            from .tracking import SHEET_DEFAULTS
            cfg = load_config("order_tracking_sheets.json", SHEET_DEFAULTS)
        else:
            cfg = load_config()
        filename = "order_tracking_sheets.json" if tracking else "google_sheets.json"
        dialog = tk.Toplevel(self.window)
        dialog.title("Google Sheets · " + ("Order Tracking" if tracking else "Onsite"))
        dialog.geometry("550x310")
        dialog.transient(self.window)
        enabled = tk.BooleanVar(value=cfg["enabled"])
        tk.Checkbutton(dialog, text="Tự gửi sau mỗi lần cào hoàn tất", variable=enabled).pack(anchor="w", padx=14, pady=8)
        fields = {}
        for key, label in [("spreadsheet_id", "Link hoặc ID Google Sheets"),
                           ("worksheet", "Tên tab (Tracking: để trống dùng tab gid=0)"), ("credentials_file", "File JSON Service Account / OAuth token")]:
            tk.Label(dialog, text=label).pack(anchor="w", padx=14)
            fields[key] = tk.StringVar(value=cfg[key])
            tk.Entry(dialog, textvariable=fields[key]).pack(fill="x", padx=14, pady=(0, 5))
        def choose():
            path = filedialog.askopenfilename(parent=dialog, title="Chọn JSON Service Account", filetypes=[("JSON", "*.json")])
            if path:
                fields["credentials_file"].set(path)
        tk.Button(dialog, text="Chọn file JSON…", command=choose).pack(anchor="w", padx=14)
        tk.Label(dialog, text=("Cập nhật cột order total theo station; giữ nguyên cột khác.\nCó thể dùng JSON Service Account hoặc token tài khoản Google." if tracking else "Chia sẻ bảng tính với client_email trong file JSON, quyền Editor.\nChỉ thêm dòng; giữ nguyên dữ liệu có sẵn."), justify="left").pack(anchor="w", padx=14, pady=6)
        def save():
            value = {**cfg, **{key: variable.get().strip() for key, variable in fields.items()}}
            value["enabled"] = enabled.get()
            try:
                if value["spreadsheet_id"]:
                    value["spreadsheet_id"] = spreadsheet_id(value["spreadsheet_id"])
                credential = Path(value["credentials_file"])
                if not credential.is_absolute():
                    credential = ROOT / credential
                if value["enabled"] and (not value["spreadsheet_id"] or not credential.is_file()):
                    raise CrawlError("Cần link bảng tính và file JSON để bật tự gửi.")
                write_json(ROOT / "config" / filename, value)
            except (CrawlError, OSError) as exc:
                messagebox.showerror("Chưa lưu được", str(exc), parent=dialog)
                return
            dialog.destroy()
        tk.Button(dialog, text="Lưu cấu hình", command=save).pack(anchor="e", padx=14, pady=4)

    def refresh(self):
        state = "Đã lưu phiên (sẽ kiểm tra quyền khi tải dữ liệu)" if STATE.exists() else "Chưa có phiên đăng nhập"
        self.status.set(state + "\nThư mục dữ liệu: " + str(ROOT))

    def open_folder(self, name):
        try:
            folder = ROOT / name
            folder.mkdir(parents=True, exist_ok=True)
            os.startfile(str(folder))
        except OSError:
            messagebox.showerror("Không mở được thư mục", str(ROOT / name))

    def start(self, mode):
        if self.busy:
            return
        if mode not in {"sheets", "tracking_sheets"} and importlib.util.find_spec("playwright") is None:
            messagebox.showerror("Thiếu thư viện", "Chạy setup.bat trước khi mở app, hoặc dùng bản EXE đã build.")
            return
        try:
            self.run_day = date.fromisoformat(self.day.get()).isoformat() if not mode.startswith("tracking") else None
        except ValueError:
            messagebox.showerror("Ngày chưa đúng", "Nhập ngày dạng YYYY-MM-DD trong ⋯.")
            return
        self.busy = True
        self.mode = mode
        self.hide_tip()
        self.indicator.configure(fg="#ffb078")
        self.finished.clear()
        for button in self.actions:
            button.configure(state="disabled")
        if mode == "capture":
            self.save.configure(state="normal")
        self.hint.set("Đang mở Chrome…" if mode in {"login", "capture"} else "Đang tải dữ liệu…")
        threading.Thread(target=self.work, args=(mode,), daemon=True).start()

    def work(self, mode):
        stream = LogStream(self.events)
        try:
            with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                if mode == "tracking":
                    from .tracking import crawl as tracking_crawl, publish
                    run = tracking_crawl(stop_event=self.finished)
                    publish(run)
                elif mode == "tracking_sheets":
                    from .tracking import publish
                    candidates = []
                    for folder in (ROOT / "outputs").glob("*_order_tracking"):
                        summary = folder / "summary.json"
                        if summary.exists() and json.loads(summary.read_text(encoding="utf-8")).get("complete"):
                            candidates.append(folder)
                    if not candidates:
                        raise CrawlError("Chưa có lần lấy tổng Order Tracking hoàn tất để gửi Sheet.")
                    publish(max(candidates, key=lambda p: p.name), force=True)
                elif mode in {"login", "tracking_login"}:
                    def confirm():
                        self.events.put(("confirm", None))
                        self.finished.wait()
                    if mode == "tracking_login":
                        from .tracking import TRACKING_URL
                        login(confirm=confirm, url=TRACKING_URL)
                    else:
                        login(confirm=confirm)
                elif mode == "capture":
                    from .onsite import capture
                    self.events.put(("hint", "Tool mở thẳng Onsite và tự mở rộng các khung giờ. Đăng nhập/chọn Hung Yen SOC nếu cần; bấm ✓ khi muốn lưu phiên."))
                    capture(stop_event=self.finished)
                elif mode == "detail":
                    from .browser_onsite import ensure_ready
                    self.events.put(("hint", "Đang mở Onsite và tự mở rộng các khung giờ. Đăng nhập nếu SPX yêu cầu; không cần bấm từng giờ."))
                    ensure_ready(open_page=True)
                    from .onsite import crawl_all
                    run = crawl_all(day=self.run_day)
                    from .sheets import publish
                    publish(run)
                elif mode == "sheets":
                    from .sheets import publish
                    candidates = []
                    for folder in (ROOT / "outputs").glob("*"):
                        summary = folder / "summary.json"
                        if summary.exists() and (folder / "onsite_view.json").exists():
                            if json.loads(summary.read_text(encoding="utf-8")).get("complete"):
                                candidates.append(folder)
                    if not candidates:
                        raise CrawlError("Chưa có lần cào hoàn tất để gửi Google Sheets.")
                    publish(max(candidates, key=lambda p: p.name), force=True)
                else:
                    from .browser_onsite import ensure_ready
                    ensure_ready()
                    from .automation import for_day
                    cfg = json.loads((ROOT / "config" / ("onsite_" + mode + ".json")).read_text(encoding="utf-8-sig"))
                    run = crawl(for_day(cfg, self.run_day))
                    from .sheets import publish
                    publish(run)
            self.events.put(("done", "Hoàn tất. Bấm ▤ để mở kết quả, hoặc ⋯ để xem nhật ký."))
        except Exception as exc:
            # Browser errors may contain URLs or headers; avoid displaying their payloads.
            detail = str(exc) if isinstance(exc, CrawlError) else type(exc).__name__ + ": kiểm tra Chrome, kết nối mạng và cấu hình."
            self.events.put(("error", detail))

    def finish(self):
        self.finished.set()
        self.save.configure(state="disabled")
        self.hint.set("Đang lưu phiên và đóng Chrome…")

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log":
                    self.log_lines.append(value)
                    self.log_lines = self.log_lines[-2000:]
                    if self.log is not None and self.log.winfo_exists():
                        self.log.configure(state="normal")
                        self.log.insert("end", value)
                        self.log.see("end")
                        self.log.configure(state="disabled")
                elif kind == "confirm":
                    self.save.configure(state="normal")
                    self.hint.set("Đăng nhập trong Chrome và chọn Hung Yen SOC, sau đó bấm Lưu phiên ở đây.")
                elif kind == "hint":
                    self.hint.set(value)
                elif kind in {"done", "error"}:
                    self.busy = False
                    self.mode = None
                    self.indicator.configure(fg="#f18a8a" if kind == "error" else "#72e0af")
                    for button in self.actions:
                        button.configure(state="normal")
                    self.save.configure(state="disabled")
                    self.hint.set(value)
                    self.refresh()
                    if kind == "error":
                        messagebox.showerror("Không hoàn tất", value)
        except queue.Empty:
            pass
        self.window.after(100, self.poll)

    def close(self):
        self.hide_tip()
        self.finished.set()
        self.exit_app()


def main():
    from .processes import own_process_tree, exit_process_tree
    from .configuration import prepare
    job = own_process_tree()
    window = tk.Tk()
    window.withdraw()
    try:
        prepare()
    except OSError:
        messagebox.showerror("Không mở được dữ liệu", "Không tạo được thư mục cấu hình: " + str(ROOT))
        exit_process_tree(job)
    Desktop(window, exit_app=lambda: exit_process_tree(job))
    window.deiconify()
    window.mainloop()
    exit_process_tree(job)
