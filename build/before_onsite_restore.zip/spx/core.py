import csv
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

PROGRAM_ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[1]
ROOT = (Path(os.environ["SPX_CRAWLER_DATA_DIR"]).expanduser().resolve() if os.environ.get("SPX_CRAWLER_DATA_DIR") else
        Path(os.environ.get("LOCALAPPDATA", str(PROGRAM_ROOT))) / "SPX_Onsite_Crawler" if getattr(sys, "frozen", False) else PROGRAM_ROOT)
BASE = "https://spx.shopee.vn"
ONSITE_URL = BASE + "/#/linehaul/onsite-registration/list"
AUTH = ROOT / ".auth"
STATE = AUTH / "storage_state.json"

class CrawlError(Exception):
    pass


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, path)


def login(channel="chrome", confirm=None, url=ONSITE_URL):
    from playwright.sync_api import sync_playwright
    AUTH.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        options = {"headless": False}
        if channel != "chromium":
            options["channel"] = channel
        context = p.chromium.launch_persistent_context(str(AUTH / "ChromeDebug_SOC"), **options)
        try:
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(url, wait_until="domcontentloaded")
            if confirm is None:
                input("Dang nhap SPX, chon Hung Yen SOC, sau do quay lai day nhan Enter: ")
            else:
                confirm()
            state = context.storage_state()
            cookies = context.cookies([BASE])
            names = {c["name"] for c in cookies}
            if not ({"spx_uid", "spx_uk"} & names):
                raise CrawlError("Chua thay cookie tai khoan SPX. Hay dang nhap lai.")
            write_json(STATE, state)
            write_json(AUTH / "spx_auth_cache.json", {
                "saved_at": datetime.now().astimezone().isoformat(),
                "base_url": BASE,
                "csrf_token": next((c["value"] for c in cookies if c["name"] == "csrftoken"), ""),
                "cookies": cookies,
                "verified_by_api": False,
            })
            print("Da luu phien. Chua xac minh bang API; se kiem tra khi ban cap endpoint.")
        finally:
            context.close()


def at(value, path):
    for key in path.split(".") if path else []:
        if isinstance(value, list) and key.isdigit():
            value = value[int(key)]
        else:
            value = value[key]
    return value


def validate(cfg):
    if cfg.get("request_confirmed") is False:
        raise CrawlError("Chua co method/params that. Chay capture-onsite truoc.")
    path = cfg.get("path", "")
    if not path.startswith("/api/") or urlsplit(path).netloc or "#" in path or "?" in path:
        raise CrawlError("path phai la /api/...; dat query trong params.")
    method = cfg.get("method", "GET").upper()
    if method not in {"GET", "POST"}:
        raise CrawlError("Chi ho tro GET/POST. POST chi dung cho API tra cuu.")
    paging = cfg.get("pagination", {})
    if paging.get("mode", "none") not in {"none", "page"}:
        raise CrawlError("pagination.mode chi ho tro none/page.")
    if paging.get("location", "params") not in {"params", "body"}:
        raise CrawlError("pagination.location phai la params/body.")
    if method == "GET" and paging.get("location") == "body":
        raise CrawlError("GET khong phan trang trong body.")
    if int(paging.get("size", 100)) < 1 or int(paging.get("max_pages", 100)) < 1:
        raise CrawlError("size/max_pages phai > 0.")
    if "rows_path" not in cfg:
        raise CrawlError("Can cau hinh rows_path theo response API.")


def fetch(api, cfg, params, body, headers=None):
    method = cfg.get("method", "GET").upper()
    # Never retry POST automatically; some endpoints can mutate data.
    attempts = 3 if method == "GET" else 1
    for attempt in range(attempts):
        options = dict(method=method, params=params, timeout=30000, max_redirects=0, headers=headers)
        if method == "POST":
            options["data"] = body
        response = api.fetch(BASE + cfg["path"], **options)
        try:
            status = response.status
            if status in {401, 403} or 300 <= status < 400:
                raise CrawlError("Phien het han/khong du quyen/redirect. Chay login lai.")
            if status == 429 or status >= 500:
                if attempt + 1 < attempts:
                    time.sleep(2 ** attempt)
                    continue
            if not response.ok:
                raise CrawlError(f"API tra HTTP {status}; khong ghi noi dung loi vao log.")
            if "json" not in response.headers.get("content-type", "").lower():
                raise CrawlError("API khong tra JSON; kiem tra dang nhap va endpoint.")
            payload = response.json()
            success = cfg.get("success")
            if success and at(payload, success["path"]) != success["equals"]:
                raise CrawlError("API bao loi nghiep vu. Kiem tra success/path va quyen truy cap.")
            return payload
        finally:
            response.dispose()


def export_csv(path, rows):
    from .exporting import flat_row
    flat = [flat_row(row) for row in rows]
    columns = list(dict.fromkeys(k for row in flat for k in row))
    with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in flat:
            # Keep spreadsheet viewers from interpreting untrusted strings as formulas.
            writer.writerow({k: "'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@", "\t", "\r")) else v for k, v in row.items()})


def crawl(config_path, run_dir=None):
    from playwright.sync_api import sync_playwright
    cfg = config_path if isinstance(config_path, dict) else json.loads(Path(config_path).read_text(encoding="utf-8-sig"))
    validate(cfg)
    if not STATE.exists():
        raise CrawlError("Chua co phien. Chay: python app.py login")
    run = Path(run_dir) if run_dir is not None else ROOT / "outputs" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    run.mkdir(parents=True)
    paging = cfg.get("pagination", {})
    paged = paging.get("mode", "none") == "page"
    first = int(paging.get("start", 1))
    limit = int(paging.get("max_pages", 100)) if paged else 1
    size = int(paging.get("size", 100))
    rows, seen_pages, seen_ids = [], set(), set()
    received = 0
    expected_total = None
    complete, reason = False, "max_pages"
    with sync_playwright() as p:
        api = p.request.new_context(storage_state=str(STATE), extra_http_headers={"Referer": BASE + "/", "Origin": BASE, "Accept": "application/json"})
        try:
            for offset in range(limit):
                # Refresh CSRF from the current request cookie jar on each page.
                cookies = api.storage_state()["cookies"]
                csrf = next((c["value"] for c in cookies if c["name"] == "csrftoken" and urlsplit(BASE).hostname.endswith(c["domain"].lstrip("."))), "")
                headers = {"Referer": BASE + "/", "Origin": BASE, "Accept": "application/json", "x-csrftoken": csrf}
                params, body = dict(cfg.get("params", {})), dict(cfg.get("body", {}))
                if paged:
                    target = body if paging.get("location", "params") == "body" else params
                    target[paging.get("page_param", "pageno")] = first + offset
                    target[paging.get("size_param", "count")] = size
                payload = fetch(api, cfg, params, body, headers)
                batch = at(payload, cfg["rows_path"])
                if not isinstance(batch, list) or any(not isinstance(r, dict) for r in batch):
                    raise CrawlError("rows_path phai tro den mang cac object.")
                digest = hashlib.sha256(json.dumps(batch, sort_keys=True).encode()).hexdigest()
                if batch and digest in seen_pages:
                    raise CrawlError("API lap lai trang cu; dung de tranh lap vo han.")
                seen_pages.add(digest)
                received += len(batch)
                if cfg.get("total_path"):
                    expected_total = int(at(payload, cfg["total_path"]))
                    if expected_total < 0:
                        raise CrawlError("data.total khong hop le.")
                write_json(run / f"page_{first + offset:05d}.json", payload)
                for row in batch:
                    key_path = cfg.get("dedupe_key")
                    if key_path:
                        key = json.dumps(at(row, key_path), sort_keys=True)
                        if key in seen_ids:
                            continue
                        seen_ids.add(key)
                    rows.append(row)
                write_json(run / "data.json", rows)
                print(f"Trang {first + offset}: {len(batch)} dong; da luu {len(rows)} dong")
                if cfg.get("total_path") and received >= expected_total:
                    complete, reason = True, "total_reached"
                    break
                if cfg.get("total_path") and (not batch or not paged):
                    raise CrawlError("Response chua du data.total; kiem tra phan trang.")
                if not paged or not batch or (not cfg.get("total_path") and paging.get("stop_on_short_page", True) and len(batch) < size):
                    complete, reason = True, "end"
                    break
                time.sleep(float(cfg.get("delay_seconds", 0.5)))
        finally:
            write_json(STATE, api.storage_state())
            api.dispose()
            if cfg.get("onsite_kind"):
                from .onsite import normalized
                view = [normalized(row, cfg["onsite_kind"]) for row in rows]
                export_csv(run / "data.csv", view)
                export_csv(run / "onsite_view.csv", view)
                write_json(run / "onsite_view.json", view)
            else:
                export_csv(run / "data.csv", rows)
            from .exporting import export_excel
            export_excel(run / "data.xlsx", view if cfg.get("onsite_kind") else rows)
            write_json(run / "summary.json", {"rows": len(rows), "complete": complete, "stop_reason": reason if complete else "error_or_max_pages", "received": received, "expected_total": expected_total})
    print(f"Da xuat: {run}")
    if not complete:
        raise CrawlError("Da cham max_pages; du lieu hien tai la mot phan. Tang gioi han neu can.")
    return run
