"""Create defaults once and retain local settings when the executable is upgraded."""
import shutil
from .core import ROOT, PROGRAM_ROOT, write_json


def prepare():
    from .onsite import template
    from .sheets import DEFAULTS
    from .tracking import defaults as tracking_defaults, SHEET_DEFAULTS
    # Import settings and API cookies from older portable builds, without replacing
    # settings that the user has already saved in the persistent data directory.
    if ROOT != PROGRAM_ROOT:
        for relative in ["config/onsite_group.json", "config/onsite_detail.json", "config/api.json",
                         "config/google_sheets.json", "config/order_tracking.json", "config/order_tracking_sheets.json",
                         ".auth/storage_state.json", ".auth/spx_auth_cache.json"]:
            source, target = PROGRAM_ROOT / relative, ROOT / relative
            if source.is_file() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    defaults = {"onsite_group.json": template("group"), "onsite_detail.json": template("detail"),
                "google_sheets.json": dict(DEFAULTS),
                "order_tracking.json": tracking_defaults(), "order_tracking_sheets.json": dict(SHEET_DEFAULTS),
                "api.json": {"path": "", "method": "GET", "params": {}, "body": {},
                             "rows_path": "data.list", "pagination": {"mode": "none"}}}
    for name, cfg in defaults.items():
        path = ROOT / "config" / name
        if not path.exists():
            write_json(path, cfg)
