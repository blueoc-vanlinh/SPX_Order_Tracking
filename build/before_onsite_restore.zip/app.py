import argparse
import json
from spx.core import ROOT, CrawlError, crawl, login


def main():
    from spx.configuration import prepare
    prepare()
    parser = argparse.ArgumentParser(description="SPX onsite crawler skeleton")
    sub = parser.add_subparsers(dest="command", required=True)
    auth = sub.add_parser("login")
    auth.add_argument("--browser", choices=["chrome", "chromium"], default="chrome")
    capture_parser = sub.add_parser("capture-onsite")
    capture_parser.add_argument("--browser", choices=["chrome", "chromium"], default="chrome")
    job = sub.add_parser("crawl")
    job.add_argument("--config", default=str(ROOT / "config" / "api.json"))
    sub.add_parser("status")
    sub.add_parser("login-tracking")
    importer = sub.add_parser("import-soc", help="Copy phien SPX va JSON Google tu bot SOC")
    importer.add_argument("--source", required=True)
    tracking = sub.add_parser("tracking-totals", help="Lay total HY SOC va tung Next Station, khong phan trang")
    tracking.add_argument("--no-publish", action="store_true", help="Chi luu Excel/CSV, khong gui Google Sheets")
    tracking.add_argument("--profile", help="Ten bo loc trong cau hinh Order Tracking")
    all_onsite = sub.add_parser("crawl-all-onsite")
    all_onsite.add_argument("--date", help="YYYY-MM-DD; reuse saved API settings for this day")
    args = parser.parse_args()
    if args.command == "import-soc":
        from spx.soc_import import import_soc
        import_soc(args.source)
    elif args.command == "login-tracking":
        from spx.tracking import TRACKING_URL
        login(url=TRACKING_URL)
    elif args.command == "tracking-totals":
        from spx.tracking import crawl as tracking_crawl, publish
        run = tracking_crawl(profile=args.profile)
        if not args.no_publish:
            publish(run)
    elif args.command == "login":
        login(args.browser)
    elif args.command == "capture-onsite":
        from spx.onsite import capture
        capture(args.browser)
    elif args.command == "crawl":
        crawl(args.config)
    elif args.command == "crawl-all-onsite":
        from spx.browser_onsite import ensure_ready
        ensure_ready(open_page=True)
        from spx.onsite import crawl_all
        crawl_all(day=args.date)
    else:
        from spx.core import STATE
        print("Da co phien luu; chua xac minh API." if STATE.exists() else "Chua co phien. Chay login.")

if __name__ == "__main__":
    try:
        main()
    except (CrawlError, KeyError, ValueError, OSError) as exc:
        # Avoid logging request headers, cookies, response bodies or credential values.
        print("Loi:", str(exc) if isinstance(exc, CrawlError) else type(exc).__name__ + ": kiem tra cau hinh/tep dau vao.")
        raise SystemExit(1)
    except KeyboardInterrupt:
        print("Da dung.")
        raise SystemExit(130)
