"""Build from an explicit allowlist so login sessions and outputs never ship."""
import argparse
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def package(exe=False):
    release = ROOT / "release"
    release.mkdir(exist_ok=True)
    if exe:
        subprocess.run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean",
                        "--onedir", "--windowed", "--name", "SPX_Onsite_Crawler",
                        "--collect-all", "playwright", "--distpath", str(ROOT / "dist"),
                        "--workpath", str(ROOT / "build"), str(ROOT / "desktop.pyw")],
                       cwd=ROOT, check=True)
        artifact = release / "SPX_Onsite_Crawler_Windows.zip"
        bundle = ROOT / "dist" / "SPX_Onsite_Crawler"
        files = [(p, p.relative_to(bundle).as_posix()) for p in bundle.rglob("*") if p.is_file()]
    else:
        artifact = release / "SPX_Onsite_Crawler_App_Source.zip"
        names = ["app.py", "desktop.pyw", "open_app.bat", "setup.bat", "build_app.bat",
                 "requirements.txt", "requirements-build.txt", "README.md", "crawl_tracking_totals.bat"]
        files = [(ROOT / name, name) for name in names]
        for directory in ["spx", "tests", "scripts"]:
            files.extend((p, p.relative_to(ROOT).as_posix()) for p in (ROOT / directory).glob("*.py"))
    files.append((ROOT / "APP_GUIDE.md", "APP_GUIDE.md"))
    files.append((ROOT / "GOOGLE_SHEETS.md", "GOOGLE_SHEETS.md"))
    files.append((ROOT / "ORDER_TRACKING.md", "ORDER_TRACKING.md"))
    # Defaults are created by the app only when missing. No local configuration,
    # credential file or session is packaged or overwritten during extraction.
    with zipfile.ZipFile(artifact, "w", zipfile.ZIP_DEFLATED) as archive:
        for path, name in files:
            archive.write(path, "SPX_Onsite_Crawler/" + name)
    print(artifact)
    return artifact


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", action="store_true")
    package(parser.parse_args().exe)
